This project is about extraction of endings and bifurcations of a poor quality
fingerprint image. The methodology used here is based on the article Fingerprint
Image Enchancement and Minutiae Extraction by Raymond Thai (2003).

img_path='Samples\0001';
addpath(img_path);
addpath('Functions\DetectROI');
addpath('Functions\bemd');
ROIL=repmat(struct('image',uint8(zeros(192,192))),1,8);
ROIR=repmat(struct('image',uint8(zeros(192,192))),1,8);
for i=1:8
    ROIL(i).image=findROI(img_path, ['\0001_m_l_0' num2str(i) '.jpg'],192,150);
    ROIR(i).image=findROI(img_path, ['\0001_m_r_0' num2str(i) '.jpg'],192,150);
end
%%
figure;
suptitle('ROI - Right Hand');
for i=1:8
    subplot(2,4,i)
    imshow(ROIL(i).image);
    title(['ROI of im 0' num2str(i) '.jpg']);
end
figure;
suptitle('ROI - Left Hand');
for j=1:8
    subplot(2,4,j)
    imshow(ROIR(j).image);
    title(['ROI of im 0' num2str(i) '.jpg']);
end
%% edge detection
figure;
suptitle('Edges - Right Hand');
for i=1:8
    subplot(2,4,i)
    imL_bf_filter=edge(ROIL(i).image,'sobel');
    imL_af_filter=bwmorph(imL_bf_filter,'bridge');
    imshow(imL_af_filter);
    title(['Edges of im 0' num2str(i) '.jpg']);
end
figure;
suptitle('Edges - Left Hand');
for j=1:8
    subplot(2,4,j)
    imR_bf_filter=edge(ROIR(i).image,'sobel');
    imR_af_filter=bwmorph(imR_bf_filter,'bridge');
    imshow(imR_af_filter);
    title(['Edges of im 0' num2str(i) '.jpg']);
end
# Low-Quality-Fingerprint-Recognition
MATLAB project for low quality fingerprint recognition by means of pre-processing and local normalization

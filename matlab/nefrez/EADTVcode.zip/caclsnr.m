function snr1 = caclsnr(I,I0)
[m n] = size(I);
a = max(I);
maxI = max(a);
Istd = maxI.^2;
Sstd = std2(I0).^2;
snr1 = 10*(log(Istd/Sstd))/log(10);
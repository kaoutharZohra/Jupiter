function [costheta,sintheta] = getEdgeDirection(f)
f =  BoundMirrorExpand(BoundMirrorExpand(BoundMirrorExpand(BoundMirrorExpand(f))));
sigma = 1.0;    % scale parameter in Gaussian kernel
gauss = fspecial('gaussian',round(3*sigma)*2+1,sigma); % Gaussian kernel
f = convbyfft(f,gauss);
[dxf1,dxc1] = fwd_cent_diff( f' ); dxc = dxc1';
[dyf,dyc] = fwd_cent_diff( f );
a = dxc;
b = dxc.*dyc;
c = dyc;

ac2 = (a.^2.0 + c.^2.0 + eps);
ac = sqrt(ac2);

costheta = - c./ac;
sintheta = a./ac;

costheta = BoundMirrorShrink(BoundMirrorShrink(BoundMirrorShrink(BoundMirrorShrink(costheta))));
sintheta = BoundMirrorShrink(BoundMirrorShrink(BoundMirrorShrink(BoundMirrorShrink(sintheta))));

function imgconv = convbyfft(img,g)
[n,m] = size(img);
[k,l] = size(g);
fimg = fft2(img,n+k-1,m+l-1); 
fg = fft2(g,n+k-1,m+l-1);
fimgg = fimg.*fg;
img_temp = real(ifft2(fimgg));
k2 = floor(k/2);
l2 = floor(l/2);
imgconv = img_temp(1+k2:n+k2,1+l2:m+l2);


function [dxf,dxc] = fwd_cent_diff(phi)
[m,n] = size(phi);
dxf = zeros(m,n);% dx using forward difference
dxc = zeros(m,n);% dx using central difference
dxf(1:m-1,:) = phi(2:m,:) - phi(1:m-1,:);
dxc(2:m-1,:) = 0.5*(phi(3:m,:) - phi(1:m-2, :));

function B = BoundMirrorExpand(A)
[m,n] = size(A);
yi = 2:m+1;
xi = 2:n+1;
B = zeros(m+2,n+2);
B(yi,xi) = A;
B([1 m+2],[1 n+2]) = B([3 m],[3 n]);  % mirror corners
B([1 m+2],xi) = B([3 m],xi);          % mirror left and right boundary
B(yi,[1 n+2]) = B(yi,[3 n]);          % mirror top and bottom boundary

function B = BoundMirrorShrink(A)
[m,n] = size(A);
yi = 2:m-1;
xi = 2:n-1;
B = A(yi,xi);

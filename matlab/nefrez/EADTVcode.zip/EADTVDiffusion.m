% Demonstration of denoising with the Edge Adptive Directional Total Variation(EADTV), 
% Modified by Yuanquan Wang, Nov.9,2012, when I saw the following DTV paper
% 'Directional Total Variation', 
% Ilker Bayram and Mustafa Kamasak,IEEE SPL, March, 2012.

clear all;
close all;

% load an image
fname = 'texture1.bmp';
% fname = 'texture1noisy.bmp';
% fname = 'zebra2.bmp';
fname = 'fig3.bmp';
dot = max(find(fname == '.'));
suffix = fname(dot+1:dot+3);
if strcmp(suffix,'pgm') | strcmp(suffix,'raw')
    [e,w,h,levels] = pgmread(fname);
else   e = imread(fname); end
if isrgb(e),  e = rgb2gray(e);  end
if isa(e,'double')~= 1,
    e = double(e);
end


im = e;
im = double(im); im = im/max(im(:));
sig = 0.05;
randn('seed', 0);            % generate seed
x = im + sig*randn(size(im)); % noisy observation

%=========================================================
lam = 0.1; %weight of the TV term in the cost function (see eq(7) in the manuscript)
alp = 5; % length of the major axis of the ellipse (minor axis is unit-length)
MAX_ITER = 200; % number of iterations 

%==============the proposed EADTV===========================================
% [costheta,sintheta] = getEdgeDirection(e);% the noise-free image acts as reference.
[costheta,sintheta] = getEdgeDirection(x);% the noisy image itself serves as reference.
[EADTV] = EADTV(x,lam,alp,costheta,sintheta,MAX_ITER); % denoising with the directional TV

difEADTV = EADTV - im;% here, im is noise-free
psnrEADTV = 10*log10(255*255/mean2((difEADTV).^2));
RMSE_EADTV = sqrt(mean(abs(difEADTV(:)).^2));
[mssimEADTV ssim_map] = ssim(im, EADTV);  
figure;imagesc(EADTV);colormap(gray);axis image;title(strcat('\alpha = ', num2str(alp), ', RMSE = ',num2str(RMSE_EADTV),' EADTV','PSNR ',num2str(psnrEADTV),'MSSIM ',num2str(mssimEADTV)));
imwrite(normalz(EADTV),strcat('lam =',num2str(lam),'alpha = ', num2str(alp),'-RMSE = ',num2str(RMSE_EADTV),'-EADTV.bmp'),'bmp');

% figure;imagesc(difEADTV);colormap(gray);axis image; title(strcat('\sigma = ', num2str(sig)));
% imwrite(normalz(difEADTV),strcat(fname(1:dot-1),'-diffEADTV-estEMap.bmp'),'bmp');


% return;
%==============the TV===========================================
% theta =0;%
% alpTV = 1;
% % [TV] = DirectionalDenoise(x,2*lam,alpTV,theta,MAX_ITER); % denoising with TV (notice the difference in lambda)
% [TV] = DirectionalDenoise(x,lam,alpTV,theta,MAX_ITER); % denoising with TV (notice the difference in lambda)
% 
% difTV = TV - im;% here, im is noise-free
% psnrTV = 10*log10(255*255/mean2((difTV).^2));
% RMSE_TV = sqrt(mean(abs(difTV(:)).^2));
% [mssimTV ssim_map] = ssim(im, TV);  
% figure;imagesc(TV);colormap(gray);axis image;title(strcat('\alpha = ', num2str(alpTV), ', RMSE = ',num2str(RMSE_TV),' TV','PSNR ',num2str(psnrTV),'MSSIM ',num2str(mssimTV)));
% imwrite(normalz(TV),strcat('lam =',num2str(lam),'alpha = ', num2str(alpTV),'-RMSE = ',num2str(RMSE_TV),'-TV.bmp'),'bmp');
% 
% figure;imagesc(difTV);colormap(gray);axis image; title(strcat('\sigma = ', num2str(sig)));
% imwrite(normalz(difTV),strcat(fname(1:dot-1),'-diffTV-estEMap.bmp'),'bmp');

%=============the DTV model=================================================
theta =0;%  % the direction of the ellipse
[DTV0] = DirectionalDenoise(x,lam,alp,theta,MAX_ITER); % denoising with the directional TV

difDTV0 = DTV0 - im;
psnrDTV0 = 10*log10(255*255/mean2((difDTV0).^2));
[mssimDTV0 ssim_map] = ssim(im, DTV0);  
RMSE_DTV0 = sqrt(mean(abs(difDTV0(:)).^2));
figure;imagesc(DTV0);colormap(gray);axis image;
title(strcat('\alpha = ', num2str(alp), ', RMSE = ',num2str(RMSE_DTV0),' DTV0-','PSNR ',num2str(psnrDTV0),'MSSIM ',num2str(mssimDTV0)));
imwrite(normalz(DTV0),strcat('lam =',num2str(lam),'alpha = ', num2str(alp),'-RMSE = ',num2str(RMSE_DTV0),'-DTV0.bmp'),'bmp');

%=============the DTV model=================================================
theta = pi/2; % the direction of the ellipse
[DTV90] = DirectionalDenoise(x,lam,alp,theta,MAX_ITER); % denoising with the directional TV

difDTV90 = DTV90 - im;
psnrDTV90 = 10*log10(255*255/mean2((difDTV90).^2));
[mssimDTV90 ssim_map] = ssim(im, DTV90);  
RMSE_DTV90 = sqrt(mean(abs(difDTV90(:)).^2));
figure;imagesc(DTV90);colormap(gray);axis image;
title(strcat('\alpha = ', num2str(alp), ', RMSE = ',num2str(RMSE_DTV90),' DTV90-','PSNR ',num2str(psnrDTV90),'MSSIM ',num2str(mssimDTV90)));
imwrite(normalz(DTV90),strcat('lam =',num2str(lam),'alpha = ', num2str(alp),'-RMSE = ',num2str(RMSE_DTV90),'-DTV90.bmp'),'bmp');
%==========================================================================

figure;imagesc(x);colormap(gray);axis image; title(strcat('\sigma = ', num2str(sig)));
imwrite(normalz(x),strcat(fname(1:dot-1),'noisy.bmp'),'bmp');

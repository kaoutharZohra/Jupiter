1 EADTVDiffusion is the main program
2 DirectionalDenoise is for DTV model, downloaded from  the homepage of Bayram, I.
3 EADTV is for EADTV, modified from DirectionalDenoise 
4 getEdgeDirection takes back the theta parameter for EADTV model
other programs are not key issues.

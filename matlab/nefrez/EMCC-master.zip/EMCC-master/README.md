# EMCC
This code implement an algorithm for encrypted domain matching of fingerprint minutia cylinder-code (MCC) with l1 minimization.
